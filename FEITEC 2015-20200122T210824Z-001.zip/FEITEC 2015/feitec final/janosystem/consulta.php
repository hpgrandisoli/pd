<?php
require_once "config_database.php";
error_reporting(1);
?>

<html>
	<head>
		<title>Consulta de Cadastro</title>
		<link rel="stylesheet" type="text/css" href="consulta.css">
	</head>
	
	<body>
		<div id="consulta_janela">
			<p>Digite o código do aluno, para obter as informações do mesmo.</p>
		</div>
		
		<form method=POST action="?go=busca_dados_php">
			<div id="formu">
				<p>Código:   <input type="text" name="num_ra" size="12"></p>
				<p><input type="submit" value="Consultar"><br>
			
		
<?php
if(@$_GET['go'] == 'busca_dados_php'){
	
	$cod = $_POST['num_ra'];
	
	if(empty($cod)){
		echo "<script>alert ('É necessário preencher o campo!'); history.back();</script>";
	}
	
	else{
		
		$query1 = mysql_num_rows(mysql_query("SELECT cod FROM cad_aluno WHERE cod = '$cod'"));		/*Faz a pesquisa no banco, para variar o if abaixo */
		$query1 = mysql_num_rows(mysql_query("SELECT nomealuno FROM cad_aluno WHERE cod = '$cod'"));
		
		
		$cod_query = mysql_result(mysql_query("SELECT cod FROM cad_aluno WHERE cod = '$cod'"), 0, "cod"); /* Traz o dado do banco contido em cod*/
		/*$ra_query = mysql_result(mysql_query("SELECT cod FROM cad_cliente WHERE ra = '$cod'"), 0, "ra"); */
		$nome_query = mysql_result(mysql_query("SELECT nomealuno FROM cad_aluno WHERE cod = '$cod'"), 0, "nomealuno");

		if($query1 == 0){
			echo "<script>alert('CÓDIGO NÃO ENCONTRADO! Digite um número válido!'); history.back(); </script>";
		}
		else{
			
?>
		<br>
<?php
		echo("Código Selecionado: "), $cod_query; 
?>
		<br>
		<br>
		<table border="1">
			<tr>
				<td>
					Código: <?php
					echo $cod_query;
					?>		
				</td>
			</tr>
		
			<tr>
				<td>
					Nome: <?php
					echo $nome_query;
					?>		
				</td>
			</tr>
		</table>
		
		<?php
			}
			/*else{ 
			
			echo "<script>alert('CÓDIGO NÃO ENCONTRADO! Digite um número válido!'); history.back(); </script>";
				
			}*/
		
		}
	}
?>

<hr>
</div>

			<a href="professor.php">
				<div id="voltar">
				Voltar
				</div>
			</a>
</body>
</html>