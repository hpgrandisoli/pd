<?php 
require_once "config_database.php";

session_start();

		$cod = $_SESSION['codigo'];
		
				
		$teste = mysql_query("SELECT * FROM cad_prof WHERE cod = '$cod'");
		$row = mysql_fetch_assoc($teste);	
?> 


<html>
	<head>
		<title>Cadastro FEITEC</title>
		<link rel="stylesheet" type="text/css" href="sala.css">
	</head>
	
	<body>
		<div style="width: 100%; height: 20%; border-color:#FFFF; border-width: 1px; border-style: solid;">
			<div id="data">
				<?php echo date('d/m/Y H:i'); ?>
			</div>
			
			<a href="consulta.php">
				<div id="consulta">
					Consultar Código 
				</div>
			</a>
			
			<a href="cad_aluno.php">
				<div id="consulta">
					Cadastrar Aluno 
				</div>
			</a>
	
			<div id="prof">
				<div id="logo">
					<img src="imagens/user-masc.jpg" alt="" style="width: 70%; height: 100%; margin-left: 15%;">
				</div>

				<div id="dados">
					
					Nome do professor:<br>
					<?php echo $row['nome'];?><br>
					<br>
					Código do professor:<br>
					<?php echo $row['cod'];?><br>
				</div>
			</div>
		</div>
		
		<form method="post" action="sala.php">
			<div id="aluno">
				<div id="alunos1">
					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>
					
					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>
				</div>
				
				
				
				
				<div id="alunos1">
					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>
					
					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>
				</div>

				
				
				<div id="alunos1">
					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>

					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>
					
					<a href="http://localhost/galinoia/aluno.php">
						<div id="aluno1">
							<img src="" alt="" style="width: 100%; height:100%;">
						</div>
					</a>
				</div>
			</div>		
		</form>
		
		<div id="sair">
			<a href="http://localhost/galinoia/professor.php">
				<input type="submit" value="Voltar" style="width:100px; margin-left:5%; margin-bot:10%"></input>
			</a>
		</div>	
	</body>
</html>