<?php 
require_once "config_database.php";

session_start();

		$cod = $_SESSION['codigo'];
		
				
		$teste = mysql_query("SELECT * FROM cad_prof WHERE cod = '$cod'");
		$row = mysql_fetch_assoc($teste);	
?> 


<html>
	<head>
		<title>Cadastro FEITEC</title>
		<link rel="stylesheet" type="text/css" href="aluno.css">
	</head>

	<body>
		<div style="width: 100%; height: 20%; border-color:#FFFF; border-width: 1px; border-style: solid;">
			<div id="data">
				<?php echo date('d/m/Y H:i'); ?>
			</div>
			
			<div id="prof">
				<div id="logo">
					<img src="imagens/user-masc.jpg" alt="" style="width: 70%; height: 100%; margin-left: 15%;">
				</div>

				<div id="dados">
					Nome do professor:<br>
					<?php echo $row['nome'];?><br>
					<br>
					Código do professor:<br>
					<?php echo $row['cod'];?><br>
				</div>
			</div>
		</div> 

		<div id="aluno"> 
			<div id="alunoa">
				<img src="imagens/user-masc.jpg" alt="" style="width: 70%; height: 100%; margin-left: 15%;">
			</div>

			<div id="nomea1">
					Nome do Aluno:<br>
					<br>
					RA:<br>
					<br>
					Idade do Aluno:<br>					
			</div> 
		</div> 
		
		<div id="ainfo">
			<div id="notaa1">
				<table border="1px" color="black">
					<tr> 
					<tr><td>Disciplina</td> <td> 1º Bimestre</td> <td> 2º Bimestre </td> <td> 3º Bimestre </td> <td> 4º Bimestre </td> <td> Média Final </td></tr>
					
					<tr>
						<td>Português</td> <td> <input type="text" size="6" name="pb1"></input> </td>  <td> <input type="text" size="6" name="pb2"></input> </td>   <td> <input type="text" size="6" name="pb3"></input> </td>   <td> <input type="text" size="6" name="pb4"></input> </td>   <td>  </td> 
					</tr>
					
					<tr>
						<td>Matemática</td> <td> <input type="text" size="6" name="mb1"></input> </td>  <td> <input type="text" size="6" name="mb2"></input> </td>   <td> <input type="text" size="6" name="mb3"></input> </td>   <td> <input type="text" size="6" name="mb4"></input> </td>   <td>  </td> 
					</tr>
					
					<tr>
						<td>Física</td> <td> <input type="text" size="6" name="fb1"></input> </td>  <td> <input type="text" size="6" name="fb2"></input> </td>   <td> <input type="text" size="6" name="fb3"></input> </td>   <td> <input type="text" size="6" name="fb4"></input> </td>   <td>  </td> 
					</tr>
					
					<tr>
						<td>Quimica</td> <td> <input type="text" size="6" name="qb1"></input> </td>  <td> <input type="text" size="6" name="qb2"></input> </td>   <td> <input type="text" size="6" name="qb3"></input> </td>   <td> <input type="text" size="6" name="qb4"></input> </td>   <td>  </td> 
					</tr>
					
					<tr>
						<td>História</td> <td> <input type="text" size="6" name="hb1"></input> </td>  <td> <input type="text" size="6" name="hb2"></input> </td>   <td> <input type="text" size="6" name="hb3"></input> </td>   <td> <input type="text" size="6" name="hb4"></input> </td>   <td>  </td> 
					</tr>
					
					<tr>
						<td>Geografia</td> <td> <input type="text" size="6" name="gb1"></input> </td>  <td> <input type="text" size="6" name="gb2"></input> </td>   <td> <input type="text" size="6" name="gb3"></input> </td>   <td> <input type="text" size="6" name="gb4"></input> </td>   <td>  </td> 
					</tr>
					
					<tr>
						<td>Inglês</td> <td> <input type="text" size="6" name="ib1"></input> </td>  <td> <input type="text" size="6" name="ib2"></input> </td>   <td> <input type="text" size="6" name="ib3"></input> </td>   <td> <input type="text" size="6" name="ib4"></input> </td>   <td>  </td> 
					</tr>					
				</table>				
			</div>
		</div>
							<a href="http://localhost/galinoia/sala.php">
						<input type="submit" value="Enviar" style="width:100px; margin-left:30%; margin-bot:10%"></input>
					</a>

						
		<div id="sair">
			<a href="http://localhost/galinoia/sala.php">
				<input type="submit" value="Voltar" style="width:100px; margin-left:5%; margin-bot:10%"></input>
			</a>
		</div>
		
	</body>
</html>