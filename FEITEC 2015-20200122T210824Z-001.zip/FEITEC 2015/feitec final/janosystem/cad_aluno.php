<?php 
require_once "config_database.php";
error_reporting(0);
?> 

<html> 
	<head> 
		<title>Cadastro Aluno</title>
		<link rel="stylesheet" type="text/css" href="cad_aluno.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://localhost/galinoia/js/jquery.maskedinput.js" type="text/javascript"></script>	
	</head>
	
	<body> 
		<form method="post" action="?go=cad_aluno">
			<div id="cad_aluno">
			<h1>Cadastro do Aluno</h1>
			</div>
			
			<div id="formu">
			<p>Nome do Aluno*:   <input type="text" name="nome_aluno" size="25" value="Nome completo..." onFocus="if (this.value=='Nome completo...') this.value='';"></p>
			<p>Número do Código do Aluno*:   <input type="text" name="cod" size="6"></p>
			
			<p>Idade*:   <input type="text" name="idade" size="1"> &nbsp Data de Nascimento*:   <input type="text" name="nasc" size="6" id="nasc"> &nbsp&nbsp <font color="grey">(AAAA-MM-DD)</font></p>
			
			<p>Sexo*:   <input type="radio" value="Masculino" name="sexo"> Masculino
			&nbsp <input type="radio" value="Feminino" name="sexo"> Feminino</p>
			
			<!--<p>Nome do Pai: &nbsp&nbsp <input type="text" name="nome_pai" size="25" value="Nome completo..." onFocus="if (this.value=='Nome completo...') this.value=' ';"></p>
			
			<p>Nome da Mãe: &nbsp&nbsp <input type="text" name="nome_mae" size="25" value="Nome completo..." onFocus="if (this.value=='Nome completo...') this.value=' ';"></p>			
			
			<p>Endereço: &nbsp&nbsp <input type="text" name="end" size="50"> &nbsp&nbsp &nbsp&nbsp	N°.: &nbsp <input type="text" name="num" size="2"></p>
			
			<p>Telefone: &nbsp&nbsp <input type="text" id="tel" name="tel" size="9"> &nbsp&nbsp &nbsp&nbsp Celular: &nbsp <input type="text" name="cel" size="9" id="cel"></p>
			
			<p> <font color="red"><strong>(*) Preenchimento necessário.</strong></font></p>
			<br> -->
			
			<p><input type="submit" value="Realizar cadastro"> &nbsp&nbsp<input type="reset" value="Limpar"></p><br>
			</div>			
		</form> 
	</body>
	
	<script>
		$(document).ready(function($){
		   $("#nasc").mask("9999-99-99");
		   $("#tel").mask("(99) 9999-9999");
		   $("#cel").mask("(99) 99999-9999");
		});
	</script>
	
<?php 
if (@$_GET['go'] == 'cad_aluno'){ /*quando o go se chamar cad_php ele realiza a ação*/ 

   $nome_aluno = $_POST['nome_aluno'];
   /*$nome_mae = $_POST['nome_mae']; 
   $nome_pai = $_POST['nome_pai']; */
   $cod = $_POST['cod']; 
   $sexo = $_POST['sexo'];
   $idade = $_POST['idade'];
   $data = $_POST['nasc'];
   /*$tel = $_POST['tel'];
   $cel = $_POST['cel'];
   $endereco = $_POST['end'];
   $num = $_POST['num'];*/
   
   
   if(empty($nome_aluno)){ 
    echo"<script>alert('Preencha os campos necessários.'); history.back();</script>"; /*chama o script para avisar que o campo está vazio*/
   }
   elseif(empty($cod)){ 
    echo"<script>alert('Preencha os campos necessários.'); history.back();</script>"; 
   } 
   elseif(empty($sexo)){    
	echo"<script>alert('Preencha os campos necessários.'); history.back();</script>"; 
   }
   elseif(empty($idade)){    
	echo"<script>alert('Preencha os campos necessários.'); history.back();</script>"; 
   }
   elseif(empty($data)){    
	echo"<script>alert('Preencha os campos necessários.'); history.back();</script>"; 
   }    
   
   else{ 
    $query = mysql_num_rows(mysql_query("SELECT * FROM cad_aluno WHERE cod = '&cod'")); /*faz a busca no banco de dados*/
	if ($query == 1){ /*o '1' indica que o aluno já está cadastrado*/
	    echo"<script>alert('O cadastro já existe'); history.back();</script>";
	} 
	else { 
	mysql_query("insert into cad_aluno (nomealuno, cod, sexo, idade, nasc, nomemae, nomepai, endereco, num, tel, cel ) values ('$nome_aluno', '$cod' , '$sexo', '$idade', '$data', '$nome_mae', '$nome_pai', '$endereco', '$num', '$tel', '$cel')"); /*insere os dados no cadastro*/
	echo "<script>alert ('Cadastro realizado'); </script>"; 
	echo "<meta http-equiv='refresh' content='0, url=sala.php'>"; 
	
	}
	
   }
	
} 

?>
	

   
   
	   
   

