<?php 
require_once "config_database.php";

session_start();

		//$nome = $_POST['nome'];
		$cod = $_SESSION['codigo'];
		
		//echo '<pre>'; print_r($_SERVER); exit;
				
		$teste = mysql_query("SELECT * FROM cad_prof WHERE cod = '$cod'");
		$row = mysql_fetch_assoc($teste);	
?> 

<html>
	<head>
		<title>Cadastro FEITEC</title>
		<link rel="stylesheet" type="text/css" href="professor.css">
	</head>
	
	<body>
		<form method="post" action="?go=busca_banco">
			<div style="width: 100%; height: 20%; border-color:#FFFF; border-width: 1px; border-style: solid;">
				<div id="data">
					<?php echo date('d/m/Y H:i'); ?>
				</div>
				
				<a href="consulta.php">
					<div id="consulta">
						Consultar Código 
					</div>
				</a>

	
				<div id="prof">
					<div id="logo">
						<img src="imagens/user-masc.jpg" alt="" style="width: 70%; height: 100%; margin-left: 15%;">
					</div>

					<div id="dados">
					
					Nome do professor:<br>
					<?php echo $row['nome'];?><br>
					<br>
					Código do professor:<br>
					<?php echo $row['cod'];?><br>

					</div>
					
				</div>
			</div>
		</form>

			<form method="post" action="professor.php">
			<div id="cont">
			<br>
				<div id="teste">
					<a href="sala.php">
						<div id="sala1">
							<img src="imagens\1f.jpg" alt="" style="height:100%, width: 100%;"> 
						</div>
					</a>

					<a href="sala.php">
						<div id="sala1">
							<img src="imagens\1g.jpg" alt="" style="height:100%, width: 100%;"> 
						</div>
					</a>
					
					<a href="sala.php">
						<div id="sala1">
							<img src="imagens\2f.jpg" alt="" style="height:100%, width: 100%;"> 
						</div>
					</a>
					
					<a href="hsala.php">
						<div id="sala1">
							<img src="imagens\2g.jpg" alt="" style="height:100%, width: 100%;"> 
						</div>
					</a>
					
				</div>
				
				<br>
				<br>
				
				<div id="teste">
					<a href="sala.php">
						<div id="sala1">
							<img src="imagens\3f.jpg" alt="" style="height:100%, width: 100%;">  
						</div>
					</a>

					<a href="sala.php">
						<div id="sala1">
							<img src="imagens\3g.jpg" alt="" style="height:100%, width: 100%;">  
						</div>
					</a>
					
					<a href="sala.php">
						<div id="sala1">
							<img src="" alt="" style="height:100%, width: 100%;"> 
						</div>
					</a>
					
					<a href="sala.php">
						<div id="sala1">
							<img src="" alt="" style="height:100%, width: 100%;">  
						</div>
					</a>
					
				</div>
			</div>
				
			</form>
			
			<a href="index.php">
				<input type="submit" value="Sair" style="width:100px; margin-left:5%; margin-bot:10%"></input>
			</a>
	</body>
</html>