<meta http-equiv="Content-Type" content="text/html, charset=utf-8">
<?php
$con = @mysql_connect("localhost", "root", "")
or die("Não foi possível conectar-se com a base de dados.");

mysql_select_db("feitec", $con) or die ("Banco de dados não encontrado.");
?>