<?php 
require_once "config_database.php";

?> 

<?php
	/*if(is_array($_POST) && count($_POST)){
		if($_POST['login'] == 'hector' && $_POST['senha'] == '123456'){
			header('Location: http://cadastrofeitec.hol.es/teste/professor.php');
		}else{
			exit('O login e senha sao invalidos.');
		}
	}*/
?>

<html>
<head>
<title>Cadastro FEITEC</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
	<body>
		<div id="logo">
			<img src="http://cadastrofeitec.hol.es/imagens/logojano.png" alt="logo" width="100%" height="100%"/>
		</div>
		
		<div id="fundo">
			<form method=POST action="?go=busca_banco">
					<div id="login">
						 Código:
						<input id="login" type="text" name="cod"></input><br>
					</div>
					<br>
					<div id="senha">
						 Senha:
						<input id="senha" type="password" name="senha"></input><br>
					</div>
							<a href="cadastro.php">Cadastre-se</a><input type="submit" value="Entrar" style="strong;"></input>
			</form>
		</div>
	</body>
	
<?php 
if (@$_GET['go'] == 'busca_banco'){ /*quando o go se chamar cad_php ele realiza a ação*/ 
 
   $cod = $_POST['cod']; 
   $senha = $_POST['senha'];
   
   if(empty($cod) || empty($senha)){
		echo "<script>alert ('É necessário preencher todos os campos!'); history.back();</script>";
	}
	else{
		
		$query1 = mysql_num_rows(mysql_query("SELECT cod FROM cad_prof WHERE cod = '$cod'")); /*Faz a busca no banco*/
		$query1 = mysql_num_rows(mysql_query("SELECT senha FROM cad_prof WHERE senha = '$senha'"));
		
	if ($query1 == 1){ /*o '1' indica que já está cadastrado*/
	    header('Location: professor.php');
		}
	else{
			echo"<script>alert('Usuário ou senha inválido.'); history.back();</script>";
		}
	}
}
	
?>	

</html>