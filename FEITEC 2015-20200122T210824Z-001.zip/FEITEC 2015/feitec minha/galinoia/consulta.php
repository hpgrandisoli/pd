<?php
require_once "config_database.php";
error_reporting(0);
?>

<html>
	<head>
		<title>Consulta de Cadastro</title>
	</head>
	
	<body>
	
	<div id="consulta_janela">
		<br><p>Digite o RA do aluno, para obter as informações do mesmo.</p></br>
		
		<form method=POST action="?go=busca_dados_php">
		
		<p>RA: &nbsp &nbsp <input type="text" name="num_ra" size="12"></p></br>
		
		<p><input type="submit" value="Consultar"><br>
		
		
<?php
if(@$_GET['go'] == 'busca_dados_php'){
	
	$ra = $_POST['num_ra'];
	
	if(empty($ra)){
		echo "<script>alert ('É necessário preencher o campo!'); history.back();</script>";
	}
	
	else{
		
		$query1 = mysql_num_rows(mysql_query("SELECT ra FROM cad_cliente WHERE ra = '$ra'"));		/*Faz a pesquisa no banco, para variar o if abaixo */
		$query1 = mysql_num_rows(mysql_query("SELECT nome FROM cad_cliente WHERE ra = '$ra'"));
		
		
		$cod_query = mysql_result(mysql_query("SELECT cod FROM cad_cliente WHERE ra = '$ra'"), 0, "cod"); 
		$ra_query = mysql_result(mysql_query("SELECT ra FROM cad_cliente WHERE ra = '$ra'"), 0, "ra"); /* Traz o dado do banco contido em RA*/
		$nome_query = mysql_result(mysql_query("SELECT nome FROM cad_cliente WHERE ra = '$ra'"), 0, "nome");

		if($query1 == 1){
			echo "<script>alert('RA encontrado! Por favor prossiga!');</script>";
			
?>

		<hr>

<?php
		echo("RA Selecionado: "), $ra_query; 
?>
		<br>
		<table border="1">

		<tr>
		<td>
		
		Codigo: <?php
		echo$cod_query;
		?>
		
		</td>
		</tr>
		
		<tr>
		<td>
		
		Nome: <?php
		echo $nome_query;
		?>
		
		</td>
		</tr>
		
		</table>
		
		<?php
			}
			else{ 
			
			echo "<script>alert('RA NÃO ENCONTRADO! Digite um número válido!'); history.back(); </script>";
				
			}
		
		}
	}
}
?>

<hr>
</div>

<a href="professor.php"> Voltar </a>
</body>
</html>