<html>
<head>
<title>Cadastro FEITEC</title>
<link rel="stylesheet" type="text/css" href="professor.css">
</head>
<body>
<div style="width: 100%; height: 20%; border-color:#FFFF; border-width: 1px; border-style: solid;">
	<div id="data">
		<?php echo date('d/m/Y H:i'); ?>
	</div>
	
	<div id="prof">
		<div id="logo">
			<img src="http://cadastrofeitec.hol.es/imagens/Koala.jpg" alt="" style="width: 100%; height: 100%;">
		</div>

		<div id="dados">
			Nome:		
		</div>
	</div>
</div>
			<form method="post" action="professor.php">
				<div id="teste">
<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>

					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>
					
					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>
					
					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>
					
				</div>
				
				
				<div id="teste">
					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>

					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>
					
					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>
					
					<a href="http://cadastrofeitec.hol.es/teste/Aluno.php">
					<div id="sala1">
						<img src="" alt="" style="height:10%, width: 10%;"> 
						</div>
</a>
					
				</div>
				
			</form>
			
			<a href="http://cadastrofeitec.hol.es">
				<input type="submit" value="Sair" style="width:100px; margin-left:5%; margin-bot:10%"></input>
			</a>
</body>
</html>