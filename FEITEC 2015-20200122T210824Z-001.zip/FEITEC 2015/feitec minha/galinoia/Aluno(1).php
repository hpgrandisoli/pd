<html>
<head>
<title>Cadastro FEITEC</title>
<link rel="stylesheet" type="text/css" href="Aluno.css">
</head>
<body>
<div style="width: 100%; height: 20%; border-color:#FFFF; border-width: 1px; border-style: solid;">
	<div id="data">
		<?php echo date('d/m/Y H:i'); ?>
	</div>
	
	<div id="prof">
		<div id="logo">
			<img src="http://cadastrofeitec.hol.es/imagens/Koala.jpg" alt="" style="width: 100%; height: 100%;">
		</div>

		<div id="dados">
			Nome:		
		</div>
	</div>
</div>
			<form method="post" action="Aluno.php">
				<div id="aluno">
				Alunos: <br>
				<div id="alunos1">
<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
					<div id="aluno1">
						<img src="" alt="" style="width: 100%; height:100%;">
					</div>
				</a>
				
				<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
					<div id="aluno1">
						<img src="" alt="" style="width: 100%; height:100%;">
					</div>
				</a>
				</div>
				
				
				
				
				<div id="alunos1">
<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
					<div id="aluno1">
						<img src="" alt="" style="width: 100%; height:100%;">
					</div>
				</a>
				
				<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
					<div id="aluno1">
						<img src="" alt="" style="width: 100%; height:100%;">
					</div>
				</a>
				</div>

				
				
				<div id="alunos1">
<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				 <a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
				 <div id="aluno1">
				 <img src="" alt="" style="width: 100%; height:100%;">
				 </div>
</a>
				<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
					<div id="aluno1">
						<img src="" alt="" style="width: 100%; height:100%;">
					</div>
				</a>
				
				<a href="http://cadastrofeitec.hol.es/teste/aluno1.php">
					<div id="aluno1">
						<img src="" alt="" style="width: 100%; height:100%;">
					</div>
				</a>
				</div>
				

				</div>		
			</form>
		<div id="sair">
			<a href="http://cadastrofeitec.hol.es">
				<input type="submit" value="Sair" style="width:100px; margin-left:5%; margin-bot:10%"></input>
			</a>
		</div>	
</body>
</html>