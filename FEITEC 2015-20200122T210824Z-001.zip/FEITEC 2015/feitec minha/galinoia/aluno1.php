<html>
<head>
<title>Cadastro FEITEC</title>
<link rel="stylesheet" type="text/css" href="aluno1.css">
</head>
<body>
<div style="width: 100%; height: 20%; border-color:#FFFF; border-width: 1px; border-style: solid;">
	<div id="data">
		<?php echo date('d/m/Y H:i'); ?>
	</div>
	
	<div id="prof">
		<div id="logo">
			<img src="http://cadastrofeitec.hol.es/imagens/Koala.jpg" alt="" style="width: 100%; height: 100%;">
		</div>

		<div id="dados">
			Nome:		
		</div>
	</div>
</div> 

<div id="aluno"> 
        <div id="teste">
		<div id="alunoa">
			<img src="http://cadastrofeitec.hol.es/imagens/bichao.jpg" alt="" style="width: 100%; height: 100%;">
		</div>

		<div id="nomea1">
			Nome do aluno:		
		</div> 
	</div>

		
</div> 
	
	<div id="ainfo">
		<div id="notaa1">
			Nota:<br> 
            <table border="1px" color="black">
<tr> 
<tr><td>Disciplina</td> <td> Media 1o Bim</td> <td> Media 2o Bim </td> <td> Media 3o Bim </td> <td> Media 4o Bim </td> <td> Media atual </td></tr>
<tr>
<td>Matematica</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td>  </td> 
</tr> 
<tr>
<td>Geografia</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td>  </td> 
</tr> 
<tr>
<td>Biologia</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td>  </td> 
</tr>
<tr>
<td>Quimica</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td> <input type="text"></input> </td>   <td>  </td> 
</tr> 
</table>		
		</div>
		
		<div id="faltasa1">
			Faltas:<br>  
<table>			
			<tr> 
<tr><td>Disciplina</td> <td> Faltas</td> <td> Porcentagem de faltas </td> </tr>
<tr>
<td>Matematica</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td>
</tr> 
<tr>
<td>Geografia</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td></td>
</tr> 
<tr>
<td>Biologia</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td> </td>
</tr>
<tr>
<td>Quimica</td> <td> <input type="text"></input> </td>  <td> <input type="text"></input> </td> </td>
</tr> 
</table>		
            			
		</div>
	</div>

		

		
</div> 
</div>
					
			</form>
		<div id="sair">
			<a href="http://cadastrofeitec.hol.es">
				<input type="submit" value="Sair" style="width:100px; margin-left:5%; margin-bot:10%"></input>
			</a>
		</div>	
</body>
</html>