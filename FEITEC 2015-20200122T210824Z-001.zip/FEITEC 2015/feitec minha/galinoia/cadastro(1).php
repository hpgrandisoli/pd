<?php 
require_once "config_database.php";

?> 
<html> 
<head> 
<title>Cadastro</title>   
<body> 
<form method="post" action="?go=cad_php">  
<p>Nome: &nbsp&nbsp <input type="text" name="nome" value="Nome completo..." onFocus="if (this.value=='Nome completo...') this.value='';"></p><br> 
<p>Número do Código: &nbsp&nbsp <input type="text" name="cod"></p><br> 
<p>Senha: &nbsp&nbsp  <input type="password" name="senha"></p><br> 
<br><br> 
<br> 
<p><input type="submit" value="Realizar cadastro"> &nbsp&nbsp<input type="reset" value="Limpar"></p><br> 

</form> 

</body> 

<?php 
if (@$_GET['go'] == 'cad_php'){ /*quando o go se chamar cad_php ele realiza a ação*/ 

   $nome = $_POST['nome']; 
   $cod = $_POST['cod']; 
   $senha = $_POST['senha']; 
   
   if(empty($nome)){ 
    echo"<script>alert('preencha todos os dados'); history.back();</script>"; /*chama o script para avisar que o campo está vazio*/
   }
   elseif(empty($cod)){ 
    echo"<script>alert('preencha todos os dados'); history.back();</script>"; 
   } 
   elseif(empty($senha)){    
	echo"<script>alert('preencha todos os dados'); history.back();</script>"; 
   } 
   
   else{ 
    $query = mysql_num_rows(mysql_query("SELECT * FROM cad_prof WHERE cod = '&cod'")); /*faz a busca no banco de dados*/
	if ($query == 1){ /*o '1' indica que o aluno já está cadastrado*/
	    echo"<script>alert('O cadastro já existe'); history.back();</script>";
	} 
	else { 
	mysql_query("insert into cad_prof (nome, cod, senha) values ('$nome', '$cod' , '$senha')"); /*insere os dados no cadastro*/
	echo "<script>alert ('Cadastro realizado'); </script>"; 
	echo "<meta http-equiv='refresh' content='0, url=./'>"; 
	
	}
	
   }
	
} 

?>
	

   
   
	   
   

